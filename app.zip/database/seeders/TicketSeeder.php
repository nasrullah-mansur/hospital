<?php

namespace Database\Seeders;

use App\Models\Ticket;
use Illuminate\Database\Seeder;

class TicketSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Ticket::create([
            'user_id' => 2,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);
        
        Ticket::create([
            'user_id' => 3,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 5,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 5,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 5,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 2,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 2,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 3,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 3,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 12,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);

        Ticket::create([
            'user_id' => 12,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);
        
        Ticket::create([
            'user_id' => 13,
            'subject' => 'Bronchus Cancers',
            'massage' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages.',
            'status' => 'new'
        ]);
    }
}
