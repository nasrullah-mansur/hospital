
<?php $__env->startSection('title'); ?>
 - Add Wound Photo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
Add Wound Photo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/dropify/dist/css/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="section-wrap">
            <div class="primary-form">
            <form action="<?php echo e(route('photo.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input name="image" type="file" class="dropify" data-max-file-size="3M" data-allowed-file-extensions="jpg jpeg png gif" id="uplodephoto">
                </div>
                <div class="form-button text-right">
                <button type="submit" class="primary-btn">Save Photo</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('admin/dropify/dist/js/dropify.min.js')); ?>"></script>
<script>
    $('.dropify').dropify();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hospital\resources\views/photos/create.blade.php ENDPATH**/ ?>