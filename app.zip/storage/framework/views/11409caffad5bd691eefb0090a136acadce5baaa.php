
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
      <div class="section-wrap">
        <div class="primary-table">
          <div class="table-responsive">
            <table class="table DataTable patient-list-table">
              <thead>
                <tr>
                  <th scope="col">Patient ID</th>
                  <th scope="col">Patient Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Phone Number</th>
                  <th scope="col">Age</th>
                  <th scope="col">Photos</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><input class="table-check" type="checkbox" /> #P-5699</td>
                  <td>
                    <div class="patient-area">
                      <div class="media patient-info">
                        <img src="assets/images/patient1.png" class="mr-3 patient-img" alt="patient" />
                        <div class="media-body">
                          <a class="patient-name" href="#">Charlene Reed </a>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>charlenereed@gmail.com </td>
                  <td>+88 000 444 666</td>
                  <td>45</td>
                  <td>(7)</td>
                  <td>
                    <div class="dropdown">
                      <button class="btn"  data-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                      </button>
                      <div class="dropdown-menu" >
                        <a class="dropdown-item" href="#">View Photos</a>
                        <a class="dropdown-item" href="#">Block User</a>
                        <a class="dropdown-item" href="#">Delete Account</a>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
    $('.DataTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('all.tickets')); ?>",
        columns: [ 
                    { data: "id" },  
                    { data: "name" },  
                    { data: "email" }, 
                    { data: "phone" }, 
                    { data: "age" }, 
                    { data: "count" }, 
                    { data: "action" }, 
                ],
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hospital\resources\views/photos/index.blade.php ENDPATH**/ ?>