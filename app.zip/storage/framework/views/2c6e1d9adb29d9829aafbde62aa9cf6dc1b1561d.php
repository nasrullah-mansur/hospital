<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\hospital\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>