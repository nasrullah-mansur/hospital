
<?php $__env->startSection('title'); ?>
<?php echo e($profile->full_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
<?php echo e($profile->full_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xl-3">
    <div class="section-wrap">
      <div class="patient-profile-info text-center">
          <img class="profile-image" src="<?php echo e($profile->image == null ? Avatar::create($profile->full_name)->toBase64() : asset($profile->image)); ?>" alt="profile-image" />
          <h3><?php echo e(ucwords($profile->full_name)); ?></h3>
          <p><?php echo e($profile->address); ?></p>
      </div>
    </div>
  </div>
  <div class="col-xl-9">
    <div class="section-wrap">
        <div class="row">
          <div class="col-lg-5">
            <div class="profile-info left-table right-border">
              <div class="table-responsive">
                <table class="table table-borderless">
                  <tbody>
                    <tr>
                      <td><span>Full Name</span></td>
                      <td><p><?php echo e(ucwords($profile->full_name)); ?></p></td>
                    </tr>
                    <tr>
                      <td><span>Gender</span></td>
                      <td><p><?php echo e($profile->gender); ?></p></td>
                    </tr>
                    <tr>
                      <td><span>Birth Date</span></td>
                      <td><p><?php echo e($profile->birth_date); ?></p></td>
                    </tr>
                    <tr>
                      <td><span>Age</span></td>
                      <td><p><?php echo e($profile->age); ?> Years</p></td>
                    </tr>
                    <tr>
                      <td><span>Address</span></td>
                      <td><p><?php echo e($profile->address); ?></p></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="col-lg-7">
            <div class="profile-info">
              <div class="table-responsive">
                <table class="table right-table table-borderless">
                  <tbody>
                    <tr>
                      <td><span>Email Adress</span></td>
                      <td><p><?php echo e($profile->user->email); ?></p></td>
                    </tr>
                    <tr>
                      <td><span>Phone Number</span></td>
                      <td><p><?php echo e($profile->phone); ?></p></td>
                    </tr>
                    <tr>
                      <td><span>Medical History</span></td>
                      <td><p><?php echo e($profile->medical_history); ?></p></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hospital\resources\views/profile/show.blade.php ENDPATH**/ ?>