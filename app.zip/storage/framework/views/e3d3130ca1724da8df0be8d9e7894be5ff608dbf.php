
<?php $__env->startSection('title'); ?>
Wound Photo - <?php echo e($name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
Wound Photos - <?php echo e($name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/vendors/css/extensions/sweetalert.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/venobox/venobox.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 mb-5">
                <div class="img-item text-center">
                    <img style="height: 160px;" src="<?php echo e(asset($photo->image)); ?>" alt="">
                </div>
                <div class="action text-center mt-3">
                    <a data-gall="gallery01" href="<?php echo e(asset($photo->image)); ?>" class="btn btn-primary venobox" style="font-size: 14px; width: 90px;">View</a>
                    <a href="javascript:void(0);" data-id="<?php echo e($photo->id); ?>" class="btn btn-danger delete-btn" style="font-size: 14px; width: 90px;">Delete</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-12">
                <?php echo e($photos->onEachSide(5)->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('admin/venobox/venobox.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendors/js/extensions/sweetalert.min.js')); ?>" type="text/javascript"></script>
<script>
    $('.venobox').venobox(); 
    $('.delete-btn').on('click',function(e){
    e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "You will not be able to recover this content!",
            icon: "warning",
            showCancelButton: true,
            buttons: {
                cancel: {
                    text: "No, cancel please!",
                    value: null,
                    visible: true,
                    className: "btn-warning",
                    closeModal: false,
                },
                confirm: {
                    text: "Yes, delete it!",
                    value: true,
                    visible: true,
                    className: "",
                    closeModal: false
                }
            }
        }).then(isConfirm => {
            if (isConfirm) {
                swal("Deleted!", "Your content has been deleted.", "success");
                window.location.replace(`/wound-photo/${e.target.getAttribute('data-id')}/destroy`);
            } else {
                swal("Cancelled", "Your content is safe", "error");
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hospital\resources\views/photos/show.blade.php ENDPATH**/ ?>